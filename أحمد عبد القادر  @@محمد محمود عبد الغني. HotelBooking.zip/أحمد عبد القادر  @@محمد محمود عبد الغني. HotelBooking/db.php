<?php
$con = mysqli_connect("localhost","root","","sourcecodester_hoteldb") or die(mysql_error());

?>